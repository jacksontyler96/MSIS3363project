﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Prototype
{
    public partial class Site1 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void lbGoToRooms_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Rooms.aspx");
        }
        protected void lbGoToHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/default.aspx");
        }
        protected void lbGoToReservations_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Reservations.aspx");
        }
        protected void lbGoToGallery_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Pictures.aspx");
        }
        protected void lbGoToContact_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Contact.aspx");
        }
    }
}