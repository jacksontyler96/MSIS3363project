﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Prototype
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["firstName"] != null)
            {
                lblResponse.Text = Session["firstName"].ToString();
            }
            if (Session["lastName"] != null)
            {
                lblResponse.Text = lblResponse.Text + " " + Session["lastName"].ToString();
            }
            if (Session["company"] != null)
            {
                lblResponse.Text = lblResponse.Text + "(" + Session["company"].ToString() + ")";
            }
            if (Session["reservationDate"] != null)
            {
                lblResponse.Text = "Your reservation is complete! Thank you " + lblResponse.Text + ", your reservation is set for " + Session["reservationDate"].ToString() + (" with the ") + Session["roomType"].ToString(); 
            }
           

        }
    }
}