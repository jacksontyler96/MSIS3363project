﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Prototype
{
    public partial class Reservations : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnConfirmation_Click(object sender, EventArgs e)
        {
            string firstName = tboxFirstName.Text;
            string lastName = tboxLastName.Text;
            string company = tboxCompany.Text;
            string reservationDate = tboxReservationTime.Text;
            string roomType = ddlRoomSelection.Text;
            Session["FirstName"] = firstName;
            Session["LastName"] = lastName;
            Session["Company"] = company;
            Session["ReservationDate"] = reservationDate;
            Session["RoomType"] = roomType;
            Response.Redirect("~/Confirmation.aspx");
        }
    }
}